@extends('layouts.app')

@section('content')

    @include('ui.headers-survey', ['showPercent' => true])

@endsection
