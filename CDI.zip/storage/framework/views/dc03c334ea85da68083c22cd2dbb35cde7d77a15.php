<div class="container">
    <div class="row justify-content-center">
        <div class="col-12">
            <h1 class="text-primary text-center w-100">Encuesta de calidad</h1>
            <?php if(!isset($finish)): ?>
                <p class="text-secondary text-center">
                    Por favor, ayúdenos a completar esta pequeña encuesta para mejorar la calidad de nuestros servicios.
                </p>
            <?php endif; ?>
        </div>
        <?php if($showPercent): ?>
            <div class="col-12 col-md-4">
                <p class="mb-0 text-secondary">Progreso</p>
                <div class="progress mb-3">
                    <div
                        class="progress-bar"
                        role="progressbar"
                        style="width: <?php echo e($percent); ?>%;"
                        aria-valuenow="<?php echo e($percent); ?>"
                        aria-valuemin="0"
                        aria-valuemax="100"><?php echo e($percent); ?>%</div>
                </div>
            </div>
        <?php endif; ?>
        <?php if(isset($finish) && $finish): ?>
            <div class="col-12">
                <p class="text-secondary text-center h4">
                    ¡Por su atención y tiempo, Gracias!
                </p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\yoshuaZea\Desktop\Projects\Laravel\centro-diagnosticos-imagen\resources\views/ui/headers-survey.blade.php ENDPATH**/ ?>