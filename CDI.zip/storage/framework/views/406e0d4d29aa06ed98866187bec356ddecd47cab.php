<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('ui.headers-survey', ['showPercent' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <form action="<?php echo e(route('survey.update', ['uuid' => $encuesta->uuid, 'pregunta' => request()->query('pregunta')])); ?>" method="POST" id="form-survey-choosen">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <input type="hidden" name="porcentaje" value="<?php echo e(old('porcentaje')); ?>">

            <div class="row justify-content-center my-3" id="choosens">
                <div class="col-12 col-md-5">
                    <label
                        class="h5 font-weight-bold <?php $__errorArgs = ['eleccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-primary <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        for="eleccion"
                    >¿Por qué eligió CDI? <small>(Elija solo una opción)</small></label>
                    <div class="d-flex flex-row flex-wrap justify-content-start gap-1">
                        <?php $__currentLoopData = $elecciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eleccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="srv-cool">
                                <input
                                    class="inp-cbx yup"
                                    type="radio"
                                    id="eleccion_<?php echo e($eleccion->id); ?>"
                                    name="eleccion"
                                    value="<?php echo e($eleccion->id); ?>"
                                    style="display: none;"
                                    <?php echo e(old("eleccion") == $eleccion->id ? 'selected' : null); ?>

                                />
                                <label class="cbx" for="eleccion_<?php echo e($eleccion->id); ?>">
                                    <span>
                                        <svg width="12px" height="10px" viewbox="0 0 12 10">
                                            <polyline points="1.5 6 4.5 9 10.5 1"></polyline>
                                        </svg>
                                    </span>
                                    <span><?php echo e($eleccion->nombre); ?></span>
                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex flex-row align-items-center">
                            <label
                                class="mb-0 mx-2 <?php $__errorArgs = ['otro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-primary <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                for="otro"
                            >Otro:</label>
                            <input
                                type="text"
                                class="form-control form-control-sm <?php $__errorArgs = ['otro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="otro"
                                name="otro"
                                placeholder="¿Por qué nos elegiste?"
                                value="<?php echo e(old('otro')); ?>"
                            >
                            <?php $__errorArgs = ['otro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div id="error-msg" class="text-primary text-sm mt-2 ml-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <?php $__errorArgs = ['eleccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div id="msg-error" class="d-block text-danger text-xs mt-2 ml-2"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php $__errorArgs = ['otro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div id="msg-error" class="d-block text-danger text-xs mt-2 ml-2"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-12 d-flex justify-content-center gap-3 mt-3">
                    <button
                        type="button"
                        class="btn text-primary"
                        onclick="window.history.back()"
                    >Anterior</button>
                    <button
                        type="submit"
                        class="btn btn-primary"
                        id="next"
                    >Finalizar</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yoshuaZea\Desktop\Projects\Laravel\centro-diagnosticos-imagen\resources\views/encuesta/question10.blade.php ENDPATH**/ ?>