<?php $__env->startSection('content'); ?>
    <div class="col-xl-10 col-lg-12 col-md-9">

        <div class="card o-hidden border-0">
            <div class="card-body border-0 p-5">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg-6 overflow-hidden d-flex justify-content-center align-items-center">
                        <img class="object-cover" src="<?php echo e(asset('img/logo.png')); ?>" alt="logo"/>
                    </div>
                    <div class="col-lg-6">
                        <div class="text-center">
                            <h1 class="h4 text-gray-900 mb-4"></h1>
                        </div>
                        <?php if(session('msg')): ?>
                            <div class="alert alert-main" role="alert">
                                <?php echo e(session('msg')); ?>

                            </div>
                        <?php endif; ?>
                        <form action="<?php echo e(route('login.post')); ?>" method="post" class="user">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input
                                    class="form-control form-control-user <?php $__errorArgs = ['usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    type="text"
                                    id="usuario"
                                    name="usuario"
                                    placeholder="Usuario"
                                />
                                <?php $__errorArgs = ['usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback ml-3" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <input
                                    class="form-control form-control-user <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    type="password"
                                    id="password"
                                    name="password"
                                    placeholder="Contraseña"
                                />
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback ml-3" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <input type="submit" class="btn btn-primary btn-user btn-block" value="Iniciar sesión">
                        </form>
                        <hr>
                        <div class="text-center">
                            <p class="small mb-0"><?php echo e(config('app.name')); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yoshuaZea\Desktop\Projects\Laravel\centro-diagnosticos-imagen\resources\views/auth/login.blade.php ENDPATH**/ ?>