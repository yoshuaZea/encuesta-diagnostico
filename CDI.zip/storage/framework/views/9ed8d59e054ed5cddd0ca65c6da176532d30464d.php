<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-sm-12 col-md-6 col-lg-7">
                <h3 class="text-center">Descarga de reportes</h3>
                <p class="text-dark text-justify">
                    Para descargar la información de encuesta de calidad es necesario seleccionar fecha de inicio y fecha final, posteriormente has clic en el botón descargar.
                </p>
                <form
                    action="<?php echo e(route('reports.download')); ?>"
                    method="post"
                    id="form_exportar"
                >
                    <?php echo csrf_field(); ?>
                    <div class="row justify-content-center mb-3">
                        <div class="col-auto">
                            <div class="form-group">
                                <label class="<?php $__errorArgs = ['tipo_reporte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 'text-danger' <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" for="text"><b>Tipo de reporte:</b></label>
                                <select
                                    class="form-control required <?php $__errorArgs = ['tipo_reporte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 'is-invalid' <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="tipo_reporte"
                                    name="tipo_reporte"
                                >
                                    <option selected disabled>Selecciona</option>
                                    <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value="<?php echo e($tipo->id); ?>"
                                            <?php echo e(old('tipo_reporte') == $tipo->id ? 'selected' : null); ?>

                                        ><?php echo e($tipo->value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php $__errorArgs = ['tipo_reporte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div id="msg-error" class="d-block text-danger text-xs mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-auto">
                            <label
                                class="<?php $__errorArgs = ['fecha_inicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 'text-danger' <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                for="fecha_inicio"><b><i class="far fa-calendar-alt mr-1"
                            ></i> Fecha de inicio</b></label>
                            <input
                                type="date"
                                class="form-control required <?php $__errorArgs = ['fecha_inicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 'is-invalid' <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="fecha_inicio"
                                name="fecha_inicio"
                                min="2022-04-01"
                                max="<?php echo e(date('Y-m-d')); ?>"
                                value="<?php echo e(old('fecha_inicio')); ?>"
                                placeholder="dd/mm/aaaa"
                                autocomplete="off"
                            >
                            <?php $__errorArgs = ['fecha_inicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div id="msg-error" class="d-block text-danger text-xs mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-auto">
                            <label
                                class="<?php $__errorArgs = ['fecha_fin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 'text-danger' <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                for="fecha_fin"><b><i class="far fa-calendar-alt mr-1"
                            ></i> Fecha fin</b></label>
                            <input
                                type="date"
                                class="form-control required <?php $__errorArgs = ['fecha_fin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 'is-invalid' <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="fecha_fin"
                                name="fecha_fin"
                                placeholder="dd/mm/aaaa"
                                min="2022-04-01"
                                max="<?php echo e(date('Y-m-d')); ?>"
                                value="<?php echo e(old('fecha_fin')); ?>"
                                autocomplete="off"
                            >
                            <?php $__errorArgs = ['fecha_fin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div id="msg-error" class="d-block text-danger text-xs mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row justify-content-center">
                        <button type="submit" id="btnSubmit" class="btn btn-primary mx-1"><i class="fas fa-download"></i> Descargar</button>
                    </div>
                </form>
                <hr>
                <form
                    action="<?php echo e(route('reports.download')); ?>"
                    method="post"
                    id="form_exportar"
                >
                    <?php echo csrf_field(); ?>
                    <p class="text-dark text-center">
                        Toma en cuenta que descargar todos los registros puede demorar un poco más de tiempo.
                    </p>
                    <div class="row justify-content-center">
                        <div class="col-auto">
                            <div class="form-group">
                                <label class="<?php $__errorArgs = ['tipo_reporte_general'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 'text-danger' <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" for="text"><b>Tipo de reporte para toda la base:</b></label>
                                <select
                                    class="form-control required <?php $__errorArgs = ['tipo_reporte_general'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 'is-invalid' <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="tipo_reporte_general"
                                    name="tipo_reporte_general"
                                >
                                    <option selected disabled>Selecciona</option>
                                    <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                            value="<?php echo e($tipo->id); ?>"
                                            <?php echo e(old('tipo_reporte_general') == $tipo->id ? 'selected' : null); ?>

                                        ><?php echo e($tipo->value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php $__errorArgs = ['tipo_reporte_general'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div id="msg-error" class="d-block text-danger text-xs mt-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row justify-content-center">
                        <input type="hidden" name="all" value="all">
                        <div class="col-auto">
                            <div class="form-group">
                                <button type="submit" id="btnSubmit" class="btn btn-outline-primary mx-1 d-block"><i class="fas fa-download"></i> Descargar todo</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/reportes.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yoshuaZea\Desktop\Projects\Laravel\centro-diagnosticos-imagen\resources\views/encuesta/reports.blade.php ENDPATH**/ ?>