<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('ui.headers-survey', ['showPercent' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <form action="<?php echo e(route('survey.update', ['uuid' => $encuesta->uuid])); ?>" method="POST" id="form-surve">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <input type="hidden" name="porcentaje" value="<?php echo e(old('porcentaje') ?? $percent); ?>">

            <div class="row justify-content-center" id="part-2">
                <div class="col-12 col-md-5">
                    <label
                        class="<?php $__errorArgs = ['estudios'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-primary <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        for="estudios"
                    >Estudios que se realizó:</label>
                    <div class="d-flex flex-row flex-wrap justify-content-between">
                        <?php $__currentLoopData = $estudios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="srv-cool ml-3">
                                <input
                                    class="inp-cbx yup"
                                    type="checkbox"
                                    id="estudios_<?php echo e($estudio->id); ?>"
                                    name="estudios[]"
                                    value="<?php echo e($estudio->id); ?>"
                                    style="display: none;"
                                    <?php echo e(old("estudios.{$estudio->id}") == $estudio->id ? 'selected' : null); ?>

                                />
                                <label class="cbx" for="estudios_<?php echo e($estudio->id); ?>">
                                    <span>
                                        <svg width="12px" height="10px" viewbox="0 0 12 10">
                                            <polyline points="1.5 6 4.5 9 10.5 1"></polyline>
                                        </svg>
                                    </span>
                                    <span><?php echo e($estudio->nombre); ?></span>
                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex flex-row align-items-center">
                            <label
                                class="mb-0 mx-2 <?php $__errorArgs = ['otro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-primary <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                for="otro"
                            >Otro:</label>
                            <input
                                type="text"
                                class="form-control form-control-sm <?php $__errorArgs = ['otro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="otro"
                                name="otro"
                                placeholder="Nombre del otro"
                                value="<?php echo e(old('otro')); ?>"
                            >
                            <?php $__errorArgs = ['otro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div id="error-msg" class="text-primary text-sm mt-2 ml-1"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <?php $__errorArgs = ['estudios'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div id="msg-error" class="d-block text-danger text-xs mt-2 ml-2"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php $__errorArgs = ['estudios.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div id="msg-error" class="d-block text-danger text-xs mt-2 ml-2"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-12 d-flex justify-content-center gap-3 mt-3">
                    <button
                        type="button"
                        class="btn text-primary"
                        id="back"
                    >Anterior</button>
                    <button
                        type="submit"
                        class="btn btn-primary"
                        id="next"
                    >Siguiente</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yoshuaZea\Desktop\Projects\Laravel\centro-diagnosticos-imagen\resources\views/encuesta/question2.blade.php ENDPATH**/ ?>