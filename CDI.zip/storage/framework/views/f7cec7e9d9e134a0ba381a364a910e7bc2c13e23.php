<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('ui.headers-survey', ['showPercent' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <form action="<?php echo e(route('survey.update.two', ['uuid' => $encuesta->uuid])); ?>" method="POST" id="form-surve">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="porcentaje" value="<?php echo e(old('porcentaje')); ?>">

            <div class="row justify-content-center align-items-center">
                <div class="col-12 col-md-4">
                    <p class="text-right font-weight-bold"><?php echo e($pregunta->nombre); ?></p>
                </div>
                <div class="col-12 col-md-8">
                    <div class="form-group d-flex flex-row">
                        <div class="btn-group btn-group-toggle" data-toggle="buttons">
                            <?php $__currentLoopData = $opciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $opcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="btn btn-options rounded w-icono">
                                    <input
                                        type="radio"
                                        id="pregunta_<?php echo e($opcion->id); ?>"
                                        name="pregunta"
                                        value="<?php echo e($opcion->id); ?>"
                                    >
                                    <p class="m-0 font-weight-bold"><?php echo e($opcion->nombre); ?></p>
                                    <i class="<?php echo e("{$opcion->icono} icono-{$opcion->color}"); ?> fa-2x"></i>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="col-12 d-flex justify-content-center gap-3 mt-3">
                    <button
                        type="submit"
                        class="btn text-primary"
                        id="back"
                    >Anterior</button>
                    <button
                        type="submit"
                        class="btn btn-primary"
                        id="next"
                    >Siguiente</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yoshuaZea\Desktop\Projects\Laravel\centro-diagnosticos-imagen\resources\views/encuesta/question3.blade.php ENDPATH**/ ?>