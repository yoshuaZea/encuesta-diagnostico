<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('ui.headers-survey', ['showPercent' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <form action="<?php echo e(route('survey.store')); ?>" method="POST" id="form-survey">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="porcentaje" value="<?php echo e(old('porcentaje')); ?>">

            <div class="row justify-content-center" id="part-1">
                <div class="col-12 col-md-4">
                    <div class="form-group">
                        <label
                            class="<?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-primary <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            for="nombre"
                        >¿Cuál es tu nombre?</label>
                        <input
                            type="text"
                            class="form-control yup <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="nombre"
                            name="nombre"
                            placeholder="Ingresa tu nombre completo"
                            value="<?php echo e(old('nombre')); ?>"
                        >
                        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div id="error-msg" class="text-primary text-sm mt-2 ml-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label
                            class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-primary <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            for="email"
                        >¿Cuál es tu correo electrónico?</label>
                        <input
                            type="text"
                            class="form-control yup <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="email"
                            name="email"
                            aria-describedby="emailHelp"
                            placeholder="correo@correo.com"
                            value="<?php echo e(old('email')); ?>"
                        >
                        <small id="emailHelp" class="form-text text-muted">No compartiremos tu correo con nadie más.</small>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div id="error-msg" class="text-primary text-sm mt-2 ml-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-12">
                    <button
                        type="submit"
                        class="btn btn-primary d-block mx-auto"
                        id="next"
                    >Siguiente</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yoshuaZea\Desktop\Projects\Laravel\centro-diagnosticos-imagen\resources\views/encuesta/index.blade.php ENDPATH**/ ?>