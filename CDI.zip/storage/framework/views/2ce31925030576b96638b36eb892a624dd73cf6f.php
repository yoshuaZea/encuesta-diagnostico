<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('ui.headers-survey', ['showPercent' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <form action="<?php echo e(route('survey.update', ['uuid' => $encuesta->uuid, 'pregunta' => request()->query('pregunta')])); ?>" method="POST" id="form-survey-questions">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <input type="hidden" name="porcentaje" value="<?php echo e(old('porcentaje')); ?>">

            <div class="row justify-content-center align-items-center" id="questions">
                <div class="col-12 col-md-12">
                    <p class="text-center font-weight-bold h5 my-4"><?php echo e($pregunta->nombre); ?></p>
                </div>
                <div class="col-12 col-md-12">
                    <div class="form-group d-flex flex-row justify-content-center">
                        <div class="btn-group btn-group-toggle gap-1 flex-wrap" data-toggle="buttons">
                            <?php $__currentLoopData = $respuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $respuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="btn btn-options rounded w-icono p-0">
                                    <input
                                        type="radio"
                                        id="respuesta_<?php echo e($respuesta->id); ?>"
                                        name="respuesta"
                                        value="<?php echo e($respuesta->id); ?>"
                                    >
                                    <p class="m-0 font-weight-bold"><?php echo e($respuesta->nombre); ?></p>
                                    <i class="<?php echo e("{$respuesta->icono} icono-{$respuesta->color}"); ?> fa-2x"></i>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php $__errorArgs = ['respuesta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div id="msg-error" class="d-block text-danger text-xs mt-2 ml-2"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-12 d-flex justify-content-center gap-3 mt-3">
                    <button
                        type="button"
                        class="btn text-primary"
                        onclick="window.history.back()"
                    >Anterior</button>
                    <button
                        type="submit"
                        class="btn btn-primary"
                        id="next"
                    >Siguiente</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yoshuaZea\Desktop\Projects\Laravel\centro-diagnosticos-imagen\resources\views/encuesta/question2to8.blade.php ENDPATH**/ ?>