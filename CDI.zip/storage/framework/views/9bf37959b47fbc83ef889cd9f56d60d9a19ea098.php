<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('ui.headers-survey', ['showPercent' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <form action="<?php echo e(route('survey.update', ['uuid' => $encuesta->uuid, 'pregunta' => request()->query('pregunta')])); ?>" method="POST" id="form-survey-suggestions">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <input type="hidden" name="porcentaje" value="<?php echo e(old('porcentaje')); ?>">

            <div class="row justify-content-center my-3">
                <div class="col-12 col-md-5">
                    <div class="form-group">
                        <label
                            class="h5 font-weight-bold <?php $__errorArgs = ['sugerencias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> text-primary <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            for="sugerencias"
                        >¿Qué le sugiere a CDI para mejorar nuestro servicio?</label>
                        <textarea
                            type="text"
                            class="form-control yup <?php $__errorArgs = ['sugerencias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="sugerencias"
                            name="sugerencias"
                            placeholder="Escribe aquí tus sugerencias..."
                            rows="5"
                            maxlength="1000"
                        ><?php echo e(old('sugerencias')); ?></textarea>
                        <?php $__errorArgs = ['sugerencias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div id="error-msg" class="text-primary text-sm mt-2 ml-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-12 d-flex justify-content-center gap-3 mt-3">
                    <button
                        type="button"
                        class="btn text-primary"
                        onclick="window.history.back()"
                    >Anterior</button>
                    <button
                        type="submit"
                        class="btn btn-primary"
                        id="next"
                    >Siguiente</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yoshuaZea\Desktop\Projects\Laravel\centro-diagnosticos-imagen\resources\views/encuesta/question9.blade.php ENDPATH**/ ?>